package com.dicoding.aplikasidicodingevent.ui.detail

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dicoding.aplikasidicodingevent.response.BaseResponse
import com.dicoding.aplikasidicodingevent.response.DetailEventResponse
import com.dicoding.aplikasidicodingevent.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailEventViewModel(application: Application) : AndroidViewModel(application) {

    private val _event = MutableLiveData<DetailEventResponse?>()
    val event: LiveData<DetailEventResponse?> = _event

    fun getDetailEvent(id: Int) {
        ApiConfig.getApiService().getDetailEvent(id.toString()).enqueue(object : Callback<BaseResponse> {
            override fun onResponse(call: Call<BaseResponse>, response: Response<BaseResponse>) {
                _event.value = response.body()?.event
            }

            override fun onFailure(call: Call<BaseResponse>, t: Throwable) {
                _event.value = null
            }
        })
    }
}
